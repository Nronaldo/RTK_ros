import rosbag
import rospy
from my_msg.msg import rinex_msg
from my_msg.msg import obs_header_msg
from my_msg.msg import BR_rinex
from my_msg.msg import BR_header
from my_msg.msg import nav_header_msg
from my_msg.msg import nav_rinex_msg
import os
import sys
import csv
import argparse
import math

GPS_Fnum_B = 0
GPS_Fnum_R = 0 
BDS_Fnum_B = 0
BDS_Fnum_R = 0

def read_data(Brinexfile,Rrinexfile,obsbag,Headtime,Tailtime):
    #parsed = parse_args()
    countSat_B = 0
    secs_B = 0
    nsecs_B = 0
    epoch_flag_B = 0
    cur_sat_num_B = 0
    #epoch_num = 0
    #header_flag = 1
    countSat_R = 0
    secs_R = 0
    nsecs_R = 0
    epoch_flag_R = 0
    cur_sat_num_R = 0
    csvfileB = open(Brinexfile,'r')
    csvfileR = open(Rrinexfile,'r')
    readerB = csv.reader(csvfileB)
    readerR = csv.reader(csvfileR)

    readerB = list(readerB)
    readerR = list(readerR)
    indexB = 0
    indexR = 0

    indexB = findfirstline(readerB,Headtime)
    indexR = findfirstline(readerR,Headtime)
    while indexR <len(readerR) and indexB < len(readerB):
        row_listB = readerB[indexB]
        row_listR = readerR[indexR]
        rowB = row_listB[0]
        rowR = row_listR[0]
        secs_B,nsecs_B,epoch_flag_B,cur_sat_num_B = read_timestamps(rowB)
        secs_R,nsecs_R,epoch_flag_R,cur_sat_num_R = read_timestamps(rowR)
        if abs(secs_B+nsecs_B*1e-9-secs_R-nsecs_R*1e-9)<=0.1:# gap too big,so discard
            GPS_satID_B,BDS_satID_B,GPS_measurements_B,BDS_measurements_B,GPS_flags_B,BDS_flags_B = GetEpochbody(indexB,readerB,cur_sat_num_B,'B')
            GPS_satID_R,BDS_satID_R,GPS_measurements_R,BDS_measurements_R,GPS_flags_R,BDS_flags_R = GetEpochbody(indexR,readerR,cur_sat_num_R,'R')
            #timestampR = rospy.Time(secs_R-18, nsecs_R)
            #timestampB = rospy.Time(secs_B-18, nsecs_B)
            writeobsbodymsg(GPS_satID_B,BDS_satID_B,GPS_measurements_B,BDS_measurements_B,GPS_flags_B,BDS_flags_B,epoch_flag_B,cur_sat_num_B,secs_B,nsecs_B,
                            GPS_satID_R,BDS_satID_R,GPS_measurements_R,BDS_measurements_R,GPS_flags_R,BDS_flags_R,epoch_flag_R,cur_sat_num_R,secs_R,nsecs_R,obsbag)
        indexB = indexB+cur_sat_num_B+1
        indexR = indexR+cur_sat_num_R+1
    csvfileB.close()
    csvfileR.close()
def GetEpochbody(index,reader,cur_sat_num,mode):
    global GPS_Fnum_B 
    global BDS_Fnum_B
    global GPS_Fnum_R 
    global BDS_Fnum_R
    GPS_satID = []
    BDS_satID = []
    GPS_measurements = []
    BDS_measurements = []
    GPS_flags = []
    BDS_flags = []
    initial_index = index
    index = index+1
    if mode == 'B':
        GPS_Fnum = GPS_Fnum_B
        BDS_Fnum = BDS_Fnum_B
    elif mode == 'R':
        GPS_Fnum = GPS_Fnum_R
        BDS_Fnum = BDS_Fnum_R
    else:
        print('no such mode')
    while index-initial_index<=cur_sat_num:   
        row_list = reader[index]
        row = row_list[0]
        index = index+1
        if row[0] == 'G':
            GPS_satID,GPS_measurements,GPS_flags = solve_measurments_flags(GPS_Fnum,row,GPS_satID,GPS_measurements,GPS_flags)
        elif row[0] == 'C':
            BDS_satID, BDS_measurements, BDS_flags = solve_measurments_flags(BDS_Fnum, row, BDS_satID,BDS_measurements,BDS_flags)
        else:
            continue
    return GPS_satID,BDS_satID,GPS_measurements,BDS_measurements,GPS_flags,BDS_flags
def findfirstline(reader,Headtime):
    index = 0
    while index < len(reader):
        row_list = reader[index]
        row = row_list[0]
        index = index+1
        if row[0] == '>':
            secs,nsecs,epoch_flag,cur_sat_num = read_timestamps(row)
            if(Headtime-secs-nsecs*1e-9)>0.2:
                continue
            else:
                break
    return index-1

def writeobsheadermsg(BDS_Fnum_B,BDS_fre_B,GPS_Fnum_B,GPS_fre_B,BDS_Fnum_R,BDS_fre_R,GPS_Fnum_R,GPS_fre_R,timestamp,obsbag):
    topic_obs_header = 'ObsHeader'
    obsheadermsg = BR_header()
    
    obsheadermsg.B_header.BDS_Fnum = BDS_Fnum_B
    obsheadermsg.B_header.GPS_Fnum = GPS_Fnum_B
    obsheadermsg.B_header.BDS_fre = BDS_fre_B
    obsheadermsg.B_header.GPS_fre = GPS_fre_B

    obsheadermsg.R_header.BDS_Fnum = BDS_Fnum_R
    obsheadermsg.R_header.GPS_Fnum = GPS_Fnum_R
    obsheadermsg.R_header.BDS_fre = BDS_fre_R
    obsheadermsg.R_header.GPS_fre = GPS_fre_R

    # time_stamp_header = rospy.Time(secs-1, nsecs)
    obsbag.write("/{0}".format(topic_obs_header),obsheadermsg,timestamp)
def writeobsbodymsg(GPS_satID_B,BDS_satID_B,GPS_measurements_B,BDS_measurements_B,GPS_flags_B,BDS_flags_B,epoch_flag_B,cur_sat_num_B,secs_B,nsecs_B,
                    GPS_satID_R,BDS_satID_R,GPS_measurements_R,BDS_measurements_R,GPS_flags_R,BDS_flags_R,epoch_flag_R,cur_sat_num_R,secs_R,nsecs_R,obsbag):
    topic_obs_body = 'ObsBody'
    obsbodymsg = BR_rinex()
    timestampR = rospy.Time(secs_R, nsecs_R)
    timestampB = rospy.Time(secs_B, nsecs_B)
    timestampRos = rospy.Time(secs_R-18, nsecs_R)
    obsbodymsg.base_body.BDS_flags = BDS_flags_B
    obsbodymsg.base_body.BDS_measurements = BDS_measurements_B
    obsbodymsg.base_body.BDS_satID = BDS_satID_B
    obsbodymsg.base_body.GPS_flags = GPS_flags_B
    obsbodymsg.base_body.GPS_measurements = GPS_measurements_B
    obsbodymsg.base_body.GPS_satID = GPS_satID_B
    obsbodymsg.base_body.GPSTime = timestampB
    obsbodymsg.base_body.epochflag = epoch_flag_B
    obsbodymsg.base_body.cur_sat_num = cur_sat_num_B

    obsbodymsg.rover_body.BDS_flags = BDS_flags_R
    obsbodymsg.rover_body.BDS_measurements = BDS_measurements_R
    obsbodymsg.rover_body.BDS_satID = BDS_satID_R
    obsbodymsg.rover_body.GPS_flags = GPS_flags_R
    obsbodymsg.rover_body.GPS_measurements = GPS_measurements_R
    obsbodymsg.rover_body.GPS_satID = GPS_satID_R
    obsbodymsg.rover_body.GPSTime = timestampR
    obsbodymsg.rover_body.epochflag = epoch_flag_R
    obsbodymsg.rover_body.cur_sat_num = cur_sat_num_R

    obsbag.write("/{0}".format(topic_obs_body),obsbodymsg,timestampRos)

def solve_measurments_flags(Frequency_num,row,satID,Measurements_array,flag_array):
    satID.append(int(row[1:3]))
    for i in range(Frequency_num):
        if (5 + i * 64 > len(row)):
            Measurements_array.append(0.0)
            Measurements_array.append(0.0)
            Measurements_array.append(0.0)
            Measurements_array.append(0.0)
            flag_array.append(0)
            flag_array.append(0)
            flag_array.append(0)
        else:
            cur_str = row[5 + i * 64:17 + i * 64]
            Measurements_array.append(0.0 if cur_str[0:4] == '    ' else float(cur_str))
            cur_str = row[20 + i * 64:33 + i * 64]
            Measurements_array.append(0.0 if cur_str[0:4] == '    ' else float(cur_str))
            cur_str = row[40 + i * 64:49 + i * 64]
            Measurements_array.append(float(cur_str) if cur_str[0:4] != '    ' else 0)
            cur_str = row[59 + i * 64:65 + i * 64]
            Measurements_array.append(float(cur_str) if cur_str[0:4] != '    ' else 0)
            cur_str = row[18 + i * 64]
            flag_array.append(int(cur_str) if cur_str is not ' ' else 0)  # qualP
            cur_str = row[34 + i * 64]
            flag_array.append(int(cur_str) if cur_str is not ' ' else 0)  # qualL
            cur_str = row[33 + i * 64]
            flag_array.append(int(cur_str) if cur_str is not ' ' else 0)  #
    return satID,Measurements_array,flag_array


def str2time(buff):
    buff_list = buff.split()
    year = int(buff_list[0])
    mon = int(buff_list[1])
    day = int(buff_list[2])
    hour = int(buff_list[3])
    min = int(buff_list[4])
    sec_double = float(buff_list[5])
    doy = [1,32,60,91,121,152,182,213,244,274,305,335]
    if (year < 1970 or year> 2099 or mon < 1 or mon>12):
        print('time format is wrong')
        return 0,0
    else:
        days = (year-1970)*365+(year-1969)/4+doy[mon-1]+day-2+(1 if (year%4==0 and mon>=3) else 0)
        sec_int = (int)(sec_double)
        sec_decimal = int((sec_double-sec_int)*1e9)
        sec_int_unix = days*86400+hour*3600+min*60+sec_int
        return sec_int_unix,sec_decimal

def read_timestamps(row):
    epochflag = int(row[31])
    cur_sat_num = int(row[32:35])
    buff = row[2:29]
    sec,nsecs = str2time(buff)
    return sec,nsecs,epochflag,cur_sat_num

def ObtainHeaderParas(rinex_file):
    GPS_Fnum = 0
    BDS_Fnum = 0
    GPS_fre = []
    BDS_fre = []
    epoch  = 0
    header_flag = 1
    with open(rinex_file,'r') as csvfile1:
        reader = csv.reader(csvfile1)
        for row_list in reader:
            row = row_list[0]
            if row[60:73] !='END OF HEADER' and row[60:79] !='SYS / # / OBS TYPES'and header_flag == 1:
                continue
            elif row[60:79] == 'SYS / # / OBS TYPES' and header_flag == 1:
                measure_num = int(row[5])
                if row[0] == 'G':
                    GPS_Fnum = measure_num/4
                    for i in range(GPS_Fnum):
                        if row[0+i*16+7:3+i*16+7] == 'C1C':
                            GPS_fre.append(1575.42)
                        elif row[0+i*16+7:3+i*16+7] == 'C2P' or row[0+i*16+7:3+i*16+7] == 'C2W':
                            GPS_fre.append(1227.60)
                        elif row[0+i*16+7:3+i*16+7] == 'C5Q'or row[0+i*16+7:3+i*16+7] == 'C5X':
                            GPS_fre.append(1176.45)
                        else:
                            continue
                elif row[0] == 'C':
                    BDS_Fnum = measure_num / 4
                    for i in range(BDS_Fnum):
                        if row[0 + i * 16 + 7:3 + i * 16 + 7] == 'C2I' or row[0 + i * 16 + 7:3 + i * 16 + 7] == 'C1I': 
                            BDS_fre.append(1561.098)
                        elif row[0 + i * 16 + 7:3 + i * 16 + 7] == 'C7I':
                            BDS_fre.append(1207.14)
                        else:
                            continue
                else:
                    continue
            else:
                if header_flag == 1:
                    header_flag =0
                else:
                    if row[0] == '>':
                        secs,nsecs,epoch_flag,cur_sat_num = read_timestamps(row)
                        if(epoch == 0):
                            basehead_t = secs+1e-9*nsecs
                        basetail_t = secs+1e-9*nsecs 
                        epoch = epoch+1        
    csvfile1.close()
    return basehead_t,basetail_t,GPS_Fnum ,BDS_Fnum,GPS_fre,BDS_fre

def  findheadtail(base_rinex,rover_rinex,obsbag):
# obtain frequency nums,frequency values of bds and GPs,obtain the begining and the end of the period with both rover data and base data
# write frequency paras to header with a timestamp of headtime-1
    basehead_t = 0
    basetail_t = 0
    roverhead_t = 0
    rovertail_t =0
    global GPS_Fnum_B
    global BDS_Fnum_B
    GPS_fre_B = []
    BDS_fre_B = []
    global GPS_Fnum_R 
    global BDS_Fnum_R
    GPS_fre_R = []
    BDS_fre_R = []
    basehead_t,basetail_t,GPS_Fnum_B,BDS_Fnum_B,GPS_fre_B,BDS_fre_B = ObtainHeaderParas(base_rinex)
    roverhead_t,rovertail_t,GPS_Fnum_R,BDS_Fnum_R,GPS_fre_R,BDS_fre_R = ObtainHeaderParas(rover_rinex)
    Headtime = basehead_t if basehead_t>roverhead_t else roverhead_t
    Tailtime = basetail_t if basetail_t<rovertail_t else rovertail_t
    timestamp = rospy.Time(int(Headtime)-1-18,(Headtime-int(Headtime))*1e9)
    writeobsheadermsg(BDS_Fnum_B,BDS_fre_B,GPS_Fnum_B,GPS_fre_B,BDS_Fnum_R,BDS_fre_R,GPS_Fnum_R,GPS_fre_R,timestamp,obsbag)
    return Headtime,Tailtime #, GPS_Fnum_B,GPS_Fnum_R,BDS_Fnum_B,BDS_Fnum_R 

def writenavheadermsg(reader,bag,navheadertime):
    msg = nav_header_msg()
    index = 0
    CORR_TYPE =[]
    ION_CORR = []
    TIME_CORR = []
    while index<len( reader):
        row_list = reader[index]
        row = row_list[0]
        index = index+1
        if(row[60:73] == 'END OF HEADER'):
            break
        elif(row[60:72] == 'LEAP SECONDS'):
            msg.LEAP_SECONDS = int(row[0:6])
        elif(row[60:76] == 'IONOSPHERIC CORR'):
            CORR_TYPE.append(row[0:4])
            i = 0
            j = 5
            while i<4:
                ION_CORR.append(str2float(row[j:j+13]))
                i = i+1
                j = j+12
        elif (row[60:76] == 'TIME SYSTEM CORR'):
            CORR_TYPE.append(row[0:4])
            TIME_CORR.append(str2float(row[5:22]))
            TIME_CORR.append(str2float(row[22:38]))
            TIME_CORR.append(str2float(row[38:45]))
            TIME_CORR.append(str2float(row[45:50]))
    msg.CORR_TYPE = CORR_TYPE
    msg.ION_CORR = ION_CORR
    msg.TIME_CORR  = TIME_CORR
    topic_nav_header = 'NavHeader'
    timestamp = rospy.Time(int(navheadertime),(navheadertime-int(navheadertime))*1e9)
    bag.write("/{0}".format(topic_nav_header),msg,timestamp)
    return index

def str2float(str):
    str = str.replace('D','E')
    return float(str)

def writenavbodymsg(index,reader,bag,navbodytime):
    GPS_ID = []
    BDS_ID = []
    GPS_NAV_DATA = []
    BDS_NAV_DATA = []
    GPS_TOC = []
    BDS_TOC = []
    msg = nav_rinex_msg()
    while index < len(reader):
        row_list = reader[index]
        row = row_list[0]
        if row[0] == 'G':
            GPS_ID, GPS_TOC,GPSNAV_DATA = solve_NAV_epoch(GPS_ID,GPS_TOC,GPS_NAV_DATA,reader,index)
        elif row[0] == 'C':
            BDS_ID, BDS_TOC,BDSNAV_DATA = solve_NAV_epoch(BDS_ID,BDS_TOC,BDS_NAV_DATA,reader,index)
        index = index+8
    msg.GPS_ID = GPS_ID
    msg.BDS_ID = BDS_ID
    msg.GPS_NAV_DATA = GPS_NAV_DATA
    msg.BDS_NAV_DATA = BDS_NAV_DATA
    msg.GPS_TOC = GPS_TOC
    msg.BDS_TOC = BDS_TOC
    topic_nav_body = 'NavBody'
    timestamp = rospy.Time(int(navbodytime),(navbodytime-int(navbodytime))*1e9)
    bag.write("/{0}".format(topic_nav_body),msg,timestamp)

def solve_NAV_epoch(GNSS_ID,GNSS_TOC,GNSS_NAV_DATA,reader,index):
    initial_index = index
    while index-initial_index<8:
        row_list = reader[index]
        row = row_list[0]
        if (index == initial_index):
            GNSS_ID.append(int(row[1:3]))
            buff_time = row[4:23]
            sec_int,sec_decimal = str2time(buff_time)
            GNSS_TOC.append(sec_int)
            i = 0
            j = 23
            while i<3:
                GNSS_NAV_DATA.append(str2float(row[j:j+19]))
                i = i+1
                j = j+19
        elif (index-initial_index<7):
            i = 0
            j = 4
            while i < 4:
                GNSS_NAV_DATA.append(str2float(row[j:j + 19]))
                i = i + 1
                j = j + 19
        else:
            i = 0
            j = 4
            while i < 2:
                GNSS_NAV_DATA.append(str2float(row[j:j + 19]))
                i = i + 1
                j = j + 19
        index = index+1   
    return GNSS_ID,GNSS_TOC,GNSS_NAV_DATA 

def read_nav_data(Navfile,navbag,navHeadtime):
    csvfile = open(Navfile, 'r')
    reader = list(csv.reader(csvfile))
    index = writenavheadermsg(reader,navbag,navHeadtime-18)
    writenavbodymsg(index,reader,navbag,navHeadtime+1-18)