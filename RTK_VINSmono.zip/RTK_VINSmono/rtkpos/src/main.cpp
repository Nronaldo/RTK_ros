#include "../include/Ephemeris.h"
#include "../include/Receiver.h"
using namespace std;
int numiterator = 0;
int debug_stop = 1193;

//int main(int argc, char ** argv) {
//	int n = 18;
//	int m = 2;
//	Eigen::MatrixXd Q = Eigen::MatrixXd::Zero(n,n);
//	Eigen::VectorXd a = Eigen::VectorXd::Zero(n);
//	Eigen::MatrixXd b  = Eigen::MatrixXd::Zero(n, m);
//	filetovector(a,n,"a");
//	filetomatrix(Q,n,n,"Q");
//	//matrixtofile(Q,"Qtest",'F');
//	int info = 0;
//	vector<double> s(2,0);
//	info = lambda(n, m, a, Q, b, s);
//	int aaaa = 1;
//
//}
int main(int argc,char ** argv){
	ros::init(argc,argv,"LsPos");
	ros::NodeHandle n;
	receiver rcv(1,1,"1",n);
	ros::Subscriber nav_header = n.subscribe("NavHeader",1000,&receiver::navheadercallback,&rcv);
	ros::Subscriber nav_body = n.subscribe("NavBody",1000,&receiver::navbodycallback,&rcv);
	ros::Subscriber obs_header = n.subscribe("ObsHeader",1000,&receiver::obsheadercallback,&rcv);
	ros::Subscriber obs_body = n.subscribe("ObsBody",1000,&receiver::obsbodycallback,&rcv);
	ros::spin();
	int a = 1;
	return 0;
}
